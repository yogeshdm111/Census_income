import streamlit as st
import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
import xgboost as xgb  
from xgboost import XGBClassifier

# Load the dataset
@st.cache
def load_data():
    df = pd.read_csv("adult.csv")
    df = df.drop_duplicates()

    df['workclass'] = df['workclass'].replace('?', 'Private')
    df['occupation'] = df['occupation'].replace('?', 'Prof-specialty')
    df['native-country'] = df['native-country'].replace('?', 'United-States')

    df.education = df.education.replace(['Preschool', '1st-4th', '5th-6th', '7th-8th', '9th', '10th', '11th', '12th'], 'School')
    df.education = df.education.replace('HS-grad', 'High School')
    df.education = df.education.replace(['Assoc-voc', 'Assoc-acdm', 'Prof-school', 'Some-college'], 'Higher-Education')
    df.education = df.education.replace('Bachelors', 'Under-Grad')
    df.education = df.education.replace('Masters', 'Graduation')
    df.education = df.education.replace('Doctorate', 'Doc')

    df['marital-status'] = df['marital-status'].replace(['Married-civ-spouse', 'Married-AF-spouse'], 'Married')
    df['marital-status'] = df['marital-status'].replace(['Never-married'], 'Unmarried')
    df['marital-status'] = df['marital-status'].replace(['Divorced', 'Separated', 'Widowed', 'Married-spouse-absent'], 'Single')

    df['income'] = df['income'].replace({'<=50K': 0, '>50K': 1})

    df = df[df['age'] <= 79]

    cat_values = list(df.select_dtypes(include='object').columns)
    df = pd.get_dummies(data=df, columns=cat_values, drop_first=True, dtype='int')

    return df

df = load_data()

st.title("Adult Census Income Prediction")
st.write("Dataset preview:")
st.dataframe(df.head())

X = df.drop(['income'], axis=1)
y = df['income']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train XGBoost model
xgb_clf = XGBClassifier()
xgb_clf.fit(X_train, y_train)
xgb_accuracy = accuracy_score(y_test, xgb_clf.predict(X_test))

st.write("### Model Accuracy")
st.write(f"XGBoost Classifier Accuracy: {xgb_accuracy:.4f}")

# Save the model and scaler
with open('XGBClassifier.pkl', 'wb') as file:
    pickle.dump(xgb_clf, file)

with open('scaler.pkl', 'wb') as file:
    pickle.dump(scaler, file)

# Prediction
st.write("### Sample Prediction")
sample = {
    'age': st.number_input('Age', min_value=0, max_value=100, value=25),
    'workclass': st.selectbox('Workclass', ['Private', 'Self-emp-not-inc', 'Self-emp-inc', 'Federal-gov', 'Local-gov', 'State-gov', 'Without-pay', 'Never-worked']),
    'fnlwgt': st.number_input('Fnlwgt', min_value=0, value=226802),
    'education': st.selectbox('Education', ['School', 'High School', 'Higher-Education', 'Under-Grad', 'Graduation', 'Doc']),
    'education-num': st.number_input('Education Num', min_value=0, value=7),
    'marital-status': st.selectbox('Marital Status', ['Married', 'Unmarried', 'Single']),
    'occupation': st.selectbox('Occupation', ['Machine-op-inspct', 'Other-service', 'Craft-repair', 'Adm-clerical', 'Exec-managerial', 'Tech-support', 'Sales', 'Farming-fishing', 'Transport-moving', 'Priv-house-serv', 'Protective-serv', 'Armed-Forces']),
    'relationship': st.selectbox('Relationship', ['Own-child', 'Husband', 'Not-in-family', 'Other-relative', 'Unmarried', 'Wife']),
    'race': st.selectbox('Race', ['Black', 'White', 'Asian-Pac-Islander', 'Amer-Indian-Eskimo', 'Other']),
    'gender': st.selectbox('Gender', ['Male', 'Female']),
    'capital-gain': st.number_input('Capital Gain', min_value=0, value=0),
    'capital-loss': st.number_input('Capital Loss', min_value=0, value=0),
    'hours-per-week': st.number_input('Hours per Week', min_value=0, max_value=100, value=40),
    'native-country': st.selectbox('Native Country', ['United-States', 'Other'])
}

sample_df = pd.DataFrame([sample])
sample_df = pd.get_dummies(sample_df, columns=list(sample_df.select_dtypes(include='object').columns), drop_first=True)
sample_df = sample_df.reindex(columns=X.columns, fill_value=0)
sample_df = scaler.transform(sample_df)

if st.button('Predict'):
    sample_prediction = xgb_clf.predict(sample_df)
    income_label = '>50K' if sample_prediction[0] == 1 else '<=50K'
    st.write(f"Sample Prediction: Income is {income_label}")
